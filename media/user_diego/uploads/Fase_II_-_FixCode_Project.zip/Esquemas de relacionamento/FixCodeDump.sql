-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `mydb` DEFAULT CHARACTER SET utf8 ;
USE `mydb` ;

-- -----------------------------------------------------
-- Table `mydb`.`User`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`User` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `firstname` VARCHAR(45) NOT NULL,
  `lastname` VARCHAR(45) NOT NULL,
  `username` VARCHAR(45) NOT NULL,
  `password` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`Profile`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`Profile` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `bio` VARCHAR(45) NULL,
  `git` VARCHAR(45) NULL,
  `imagem_perfil` VARCHAR(45) NULL,
  `data_cadastro` VARCHAR(45) NOT NULL,
  `User_id` INT NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_Profile_User_idx` (`User_id` ASC),
  CONSTRAINT `fk_Profile_User`
    FOREIGN KEY (`User_id`)
    REFERENCES `mydb`.`User` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`Areas`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`Areas` (
  `id` INT NOT NULL,
  `nome_linguagem` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`Areas_has_Profile`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`Areas_has_Profile` (
  `Areas_id` INT NOT NULL,
  `Profile_id` INT NOT NULL,
  PRIMARY KEY (`Areas_id`, `Profile_id`),
  INDEX `fk_Areas_has_Profile_Profile1_idx` (`Profile_id` ASC),
  INDEX `fk_Areas_has_Profile_Areas1_idx` (`Areas_id` ASC),
  CONSTRAINT `fk_Areas_has_Profile_Areas1`
    FOREIGN KEY (`Areas_id`)
    REFERENCES `mydb`.`Areas` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Areas_has_Profile_Profile1`
    FOREIGN KEY (`Profile_id`)
    REFERENCES `mydb`.`Profile` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`Fixies`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`Fixies` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `titulo` VARCHAR(45) NOT NULL,
  `descrição` LONGTEXT NOT NULL,
  `data` DATE NOT NULL,
  `resolvido` TINYINT(1) NOT NULL DEFAULT 0,
  `tem_melhor_resposta` TINYINT(1) NOT NULL DEFAULT 0,
  `notificaçao` INT NULL DEFAULT 0,
  `User_id` INT NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_Fixies_User1_idx` (`User_id` ASC),
  CONSTRAINT `fk_Fixies_User1`
    FOREIGN KEY (`User_id`)
    REFERENCES `mydb`.`User` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`Areas_has_Fixies`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`Areas_has_Fixies` (
  `Areas_id` INT NOT NULL,
  `Fixies_id` INT NOT NULL,
  PRIMARY KEY (`Areas_id`, `Fixies_id`),
  INDEX `fk_Areas_has_Fixies_Fixies1_idx` (`Fixies_id` ASC),
  INDEX `fk_Areas_has_Fixies_Areas1_idx` (`Areas_id` ASC),
  CONSTRAINT `fk_Areas_has_Fixies_Areas1`
    FOREIGN KEY (`Areas_id`)
    REFERENCES `mydb`.`Areas` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Areas_has_Fixies_Fixies1`
    FOREIGN KEY (`Fixies_id`)
    REFERENCES `mydb`.`Fixies` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`CommentFixies`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`CommentFixies` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `comment` LONGTEXT NOT NULL,
  `data` DATE NOT NULL,
  `melhor_resposta` TINYINT(1) NULL DEFAULT 0,
  `User_id` INT NOT NULL,
  `Fixies_id` INT NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_ComentFixies_User1_idx` (`User_id` ASC),
  INDEX `fk_ComentFixies_Fixies1_idx` (`Fixies_id` ASC),
  CONSTRAINT `fk_ComentFixies_User1`
    FOREIGN KEY (`User_id`)
    REFERENCES `mydb`.`User` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_ComentFixies_Fixies1`
    FOREIGN KEY (`Fixies_id`)
    REFERENCES `mydb`.`Fixies` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`Participations`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`Participations` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `notificação` INT NOT NULL DEFAULT 0,
  `ativa_notificação` TINYINT(1) NOT NULL DEFAULT 1,
  `Fixies_id` INT NOT NULL,
  `User_id` INT NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_Participations_Fixies1_idx` (`Fixies_id` ASC),
  INDEX `fk_Participations_User1_idx` (`User_id` ASC),
  CONSTRAINT `fk_Participations_Fixies1`
    FOREIGN KEY (`Fixies_id`)
    REFERENCES `mydb`.`Fixies` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Participations_User1`
    FOREIGN KEY (`User_id`)
    REFERENCES `mydb`.`User` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`Favorites`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`Favorites` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `notificação` INT NOT NULL DEFAULT 0,
  `User_id` INT NOT NULL,
  `Fixies_id` INT NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_Favorites_User1_idx` (`User_id` ASC),
  INDEX `fk_Favorites_Fixies1_idx` (`Fixies_id` ASC),
  CONSTRAINT `fk_Favorites_User1`
    FOREIGN KEY (`User_id`)
    REFERENCES `mydb`.`User` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Favorites_Fixies1`
    FOREIGN KEY (`Fixies_id`)
    REFERENCES `mydb`.`Fixies` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`Followers`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`Followers` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `block` TINYINT(1) NULL DEFAULT 0,
  `data` DATE NULL,
  `user` INT NOT NULL,
  `following` INT NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_Followers_User1_idx` (`user` ASC),
  INDEX `fk_Followers_User2_idx` (`following` ASC),
  CONSTRAINT `fk_Followers_User1`
    FOREIGN KEY (`user`)
    REFERENCES `mydb`.`User` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Followers_User2`
    FOREIGN KEY (`following`)
    REFERENCES `mydb`.`User` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`Post`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`Post` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `titulo` VARCHAR(45) NOT NULL,
  `post` LONGTEXT NOT NULL,
  `data` DATE NOT NULL,
  `notificação` INT NOT NULL DEFAULT 0,
  `ativa_notificação` TINYINT(1) NOT NULL DEFAULT 1,
  `exibir_perfil` TINYINT(1) NOT NULL DEFAULT 1,
  `anexo` VARCHAR(45) NULL,
  `User_id` INT NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_Post_User1_idx` (`User_id` ASC),
  CONSTRAINT `fk_Post_User1`
    FOREIGN KEY (`User_id`)
    REFERENCES `mydb`.`User` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`CommentPost`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`CommentPost` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `comment` LONGTEXT NOT NULL,
  `data` DATE NOT NULL,
  `Post_id` INT NOT NULL,
  `User_id` INT NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_CommentPost_Post1_idx` (`Post_id` ASC),
  INDEX `fk_CommentPost_User1_idx` (`User_id` ASC),
  CONSTRAINT `fk_CommentPost_Post1`
    FOREIGN KEY (`Post_id`)
    REFERENCES `mydb`.`Post` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_CommentPost_User1`
    FOREIGN KEY (`User_id`)
    REFERENCES `mydb`.`User` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`Post_has_Areas`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`Post_has_Areas` (
  `Post_id` INT NOT NULL,
  `Areas_id` INT NOT NULL,
  PRIMARY KEY (`Post_id`, `Areas_id`),
  INDEX `fk_Post_has_Areas_Areas1_idx` (`Areas_id` ASC),
  INDEX `fk_Post_has_Areas_Post1_idx` (`Post_id` ASC),
  CONSTRAINT `fk_Post_has_Areas_Post1`
    FOREIGN KEY (`Post_id`)
    REFERENCES `mydb`.`Post` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Post_has_Areas_Areas1`
    FOREIGN KEY (`Areas_id`)
    REFERENCES `mydb`.`Areas` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
