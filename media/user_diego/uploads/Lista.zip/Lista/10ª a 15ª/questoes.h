#include <stdlib.h>
#include <stdio.h>

typedef struct arv_var ArvVar;
typedef struct arvv_no ArvVarNo;
typedef struct no_arvBin ArvBin;

ArvVarNo *arvV_criaNo(int c);
void arvV_insere(ArvVarNo *a, ArvVarNo *sa);
ArvVar *arvV_cria(ArvVarNo *r);
void arvV_imprime(ArvVar *a);
void imprime(ArvVarNo *r);
ArvVarNo *arvV_busca(ArvVar *a, int c);
void arvV_libera(ArvVar *a);
int impares(ArvVar *a);
int conta_impar(ArvVarNo *r);
int quant_folhas(ArvVarNo *r);
int arvv_folhas(ArvVar* a);
int quant_uma_folha(ArvVarNo *r);
int um_filho_arvv (ArvVar* a);
int arvv_igual (ArvVar* a, ArvVar* b);
int verifica_igualdade(ArvVarNo* a, ArvVarNo* b);
ArvVar* arvv_pai(ArvVar* a, int no);
ArvVarNo *busca_pai(ArvVarNo *r, int no);
int percorre_lista(ArvVarNo *r, int no);
ArvBin* transformaBin(ArvVar* a);
void para_bin(ArvVarNo *var, ArvBin *bin);
ArvBin *criar();

