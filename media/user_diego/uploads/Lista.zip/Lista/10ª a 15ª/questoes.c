#include "questoes.h"

struct arvv_no{
    int info;
    ArvVarNo *prim;
    ArvVarNo *prox;
};

struct arv_var{
    ArvVarNo *raiz;
};

struct no_arvBin{
    int info;
    ArvBin *esq;
    ArvBin *dir;
};

ArvVarNo *arvV_criaNo(int c){
    ArvVarNo *a = (ArvVarNo*)malloc(sizeof(ArvVarNo*));
    a->info = c;
    a->prim = NULL;
    a->prox = NULL;
    return a;
}

ArvVar *arvV_cria(ArvVarNo *r){
    ArvVar *a = (ArvVar*)malloc(sizeof(ArvVar));
    a->raiz = r;
    return a;
}

void arvV_insere(ArvVarNo *a, ArvVarNo *sa){
    sa->prox = a->prim;
    a->prim = sa;
}

void arvV_imprime(ArvVar *a){
    if(a->raiz != NULL)
        imprime(a->raiz);
}

void imprime(ArvVarNo *r){
    printf("<%d", r->info);
    ArvVarNo *p = r->prim;
    while(p!=NULL){
        imprime(p);
        printf(">");
        p = p->prox;
    }
}

//décima questão
int impares(ArvVar *a){
    return conta_impar(a->raiz);
}

int conta_impar(ArvVarNo *r){
    if (r == NULL)return 0;int var = 0;
    if (r->info % 2 != 0)
        var = 1;
    return conta_impar(r->prox) + conta_impar(r->prim) + var;
}

//decima primeira questão
int arvv_folhas(ArvVar* a){
    return quant_folhas(a->raiz);
}

int quant_folhas(ArvVarNo *r){
    if (r == NULL)return 0;
    int var = 0;
    if (r->prim == NULL)
        var = 1;
    return quant_folhas(r->prox) + quant_folhas(r->prim) + var;
}

//décima segunda questão
int um_filho_arvv (ArvVar* a){
    return quant_uma_folha(a->raiz);
}

int quant_uma_folha(ArvVarNo *r){
    if(r == NULL)return 0;
    int var = 0;
    if(r->prim != NULL && r->prim->prox == NULL)
        var = 1;
    return quant_uma_folha(r->prox) + quant_uma_folha(r->prim) + var;
}

//decima terceira questão
int arvv_igual (ArvVar* a, ArvVar* b){
    return verifica_igualdade(a->raiz, b->raiz);
}

int verifica_igualdade(ArvVarNo* a, ArvVarNo* b){
    if(a == NULL && b == NULL)
        return 1;
    if(a == NULL || b == NULL)
        return 0;
    return ((a->info == b->info) && verifica_igualdade(a->prox, b->prox) && verifica_igualdade(a->prim, b->prim));
}

//décima quarta questão
ArvVar* arvv_pai(ArvVar* a, int no){
    if (a->raiz->info == no)
        return NULL;
    ArvVarNo *pai = busca_pai(a->raiz, no);
    return pai;
}

ArvVarNo *busca_pai(ArvVarNo *r, int no){
    if (r == NULL)
        return NULL;
    else if (percorre_lista(r->prim, no) == 1)
        return r->info;
}

int percorre_lista(ArvVarNo *r, int no){
    int peso = 0;
    ArvVarNo *aux = r;
    while(aux != NULL){
        if(aux->info == no)
            peso = 1;
        aux = aux->prox;
    }
    if(peso == 1)
        return peso;
    else{
        ArvVarNo *aux = r;
        while(aux != NULL){
            if (aux->prim != NULL)
                if (busca_pai(aux, no) != NULL)return;
            aux = aux->prox;
        }
    }
}


//décima quinta questão
/*Caro monitor, observe a lógica da função pois não sei porque raios isso tá dando errado! Pra mim está certo.*/
ArvBin* transformaBin (ArvVar* a){
    ArvBin *raizb;
    para_bin(a->raiz, raizb);
    return raizb;
}


void para_bin(ArvVarNo *var, ArvBin *bin){
    if (var != NULL){
        ArvBin *no = (ArvBin*)malloc(sizeof(ArvBin));
        no->info = var->info;
        no->esq = NULL;
        no->dir = NULL;
        bin = no;
        para_bin(var->prim, bin->esq);
        para_bin(var->prox, bin->dir);
    }
}
