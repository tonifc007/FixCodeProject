#include "questoes.h"

int main()
{
    ArvVarNo *a = arvV_criaNo(1);
    ArvVarNo *b = arvV_criaNo(2);
    ArvVarNo *c = arvV_criaNo(3);
    ArvVarNo *d = arvV_criaNo(4);
    ArvVarNo *e = arvV_criaNo(5);
    ArvVarNo *f = arvV_criaNo(6);
    ArvVarNo *g = arvV_criaNo(7);
    ArvVarNo *h = arvV_criaNo(8);
    ArvVarNo *i = arvV_criaNo(9);
    ArvVarNo *j = arvV_criaNo(10);

    arvV_insere(c,d);
    arvV_insere(b,e);
    arvV_insere(b,c);
    arvV_insere(i,j);
    arvV_insere(g,i);
    arvV_insere(g,h);
    arvV_insere(a,g);
    arvV_insere(a,f);
    arvV_insere(a,b);

    ArvVar *arvore =arvV_cria(a);
    arvV_imprime(arvore);
    printf("\nNumeros impares: %d", impares(arvore));
    printf("\nQuantidade de folhas na arvore: %d", arvv_folhas(arvore));
    printf("\nQuantidade de nós com apenas um filho: %d", um_filho_arvv(arvore));
    printf("\nArvores são iguais? %d", arvv_igual(arvore, arvore));
    printf("\nO pai desse no eh: %d", arvv_pai(arvore, 5));
    ArvBin *t = transformaBin(arvore);
    return 0;
}
