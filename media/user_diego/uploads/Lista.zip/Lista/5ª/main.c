#include "questoes.h"

int main()
{
    ArvBin* raiz = criar();
    ArvBin* e1 = criar();
    ArvBin* e2 = criar();
    ArvBin* e3 = criar();
    ArvBin* e4 = criar();
    ArvBin* e5 = criar();
    ArvBin* e6 = criar();
    ArvBin* e7 = criar();
    ArvBin* e8 = criar();

    e1 = insereValor(6, NULL, NULL);
    e2 = insereValor(3, NULL, NULL);
    e3 = insereValor(4, NULL, NULL);
    e4 = insereValor(1, NULL, NULL);
    e5 = insereOp('-', e1, e2);
    e6 = insereOp('+', e3, e4);
    e7 = insereOp('*', e5, e6);
    e8 = insereValor(5, NULL, NULL);
    raiz = insereOp('+', e7, e8);

    imprimir_em_ordem(raiz);
    printf("\n");
    imprime_Expre(raiz);
    printf("\nValor: %f", avalia(raiz));

    return 0;
}
