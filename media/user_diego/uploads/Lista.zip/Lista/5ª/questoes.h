#include <stdio.h>
#include <stdlib.h>

typedef struct arv ArvBin;

ArvBin* raiz;
ArvBin* insereOp(char n, ArvBin* e, ArvBin* d);
ArvBin* insereValor(float n, ArvBin* e, ArvBin* d);
ArvBin* criar();
void imprimir_em_ordem(ArvBin* r);
void imprime_Expre(ArvBin* a);
float avalia(ArvBin *a);
