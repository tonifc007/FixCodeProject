#include <stdlib.h>
#include <stdio.h>
#include <string.h>

typedef struct aluno Aluno;
typedef struct arvBinB ArvBinB;
typedef struct no_arvBinB ArvBinB_No;

ArvBinB *aa_cria();
ArvBinB_No *insere(ArvBinB_No *a, char *nome, float p1, float p2, float p3);
void aa_insere (ArvBinB* a, char* nome, float p1, float p2, float p3);
void abb_imprime(ArvBinB *a);
void imprime_em_ordem(ArvBinB_No *a);
float aa_media (ArvBinB* a, char* nome);
ArvBinB_No *busca_media(ArvBinB_No *a, char *nome);
void aa_retira(ArvBinB *a, char *nome);
ArvBinB_No *retira(ArvBinB_No *r, char *nome);
void aa_libera(ArvBinB *a);
void desaloca(ArvBinB_No *r);
