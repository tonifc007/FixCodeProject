#include "questoes.h"

int main()
{
    ArvBinB *r = aa_cria();
    aa_insere(r, "diego", 8,9,10);
    aa_insere(r, "leticia", 8.4,4.5,10);
    aa_insere(r, "lohayne", 9.6,8.8,10);
    abb_imprime(r);
    printf("\n\nMedia: %f", aa_media(r, "diego"));
    aa_retira(r, "lohayne");
    abb_imprime(r);
    aa_libera(r);
    abb_imprime(r);
    return 0;
}
