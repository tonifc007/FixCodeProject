#include "questoes.h"

int main()
{
    ArvBin* raiz = criar();
    ArvBin* e1 = criar();
    ArvBin* e2 = criar();
    ArvBin* e3 = criar();
    ArvBin* e4 = criar();
    ArvBin* d1 = criar();

    e1 = insere(15, NULL, NULL);
    e2 = insere(20, NULL, NULL);
    e3 = insere(30, e1, e2);
    e4 = insere(50, NULL, NULL);
    d1 = insere(40, e4, NULL);

    raiz = insere(10, e3, d1);
    ArvBin* r = criar();
    r = insere(10, e3, d1);
    printf("\nQuantidade de nos que guardam numeros pares: %d", pares(raiz));
    printf("\nQuantidade de folhas: %d", folhas(raiz));
    printf("\nQuantidade de folhas com apenas um filho: %d", um_filho(raiz));

    ArvBin *rai = criar();
    ArvBin *a1 = criar();
    ArvBin *a2 = criar();

    a1 = insere(1, NULL, NULL);
    a2 = insere(2, NULL, NULL);
    rai = insere(3, a1, a2);
    printf("\nQuantidade de nos que guardam numeros pares: %d", pares(rai));
    printf("\nQuantidade de folhas: %d", folhas(rai));
    printf("\nQuantidade de folhas com apenas um filho: %d", um_filho(rai));

    printf("\n\nArvores iguais? %d", igual(raiz, r));
    printf("\n\nArvores iguais? %d", igual(raiz, rai));

    return 0;
}
