#include <stdio.h>
#include <stdlib.h>

typedef struct NO ArvBin;

ArvBin *raiz;
ArvBin* insere(int n, ArvBin* e, ArvBin* d);
ArvBin *criar();
int pares(ArvBin *a);
int folhas(ArvBin *a);
int um_filho(ArvBin *a);
int igual(ArvBin *a, ArvBin *b);
