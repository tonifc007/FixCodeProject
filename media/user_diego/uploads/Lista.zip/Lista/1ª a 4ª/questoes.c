#include "questoes.h"

struct NO{
    int info;
    struct NO *esq;
    struct NO *dir;
};

ArvBin* insere(int n, ArvBin* e, ArvBin* d){
    ArvBin* aux = (ArvBin*)malloc(sizeof(ArvBin));
    aux->info = n;
    aux->esq = e;
    aux->dir = d;
    return aux;
}


ArvBin *criar(){
    return NULL;
}

//primeira questão
int pares(ArvBin *a){
    if(a == NULL)
        return 0;
    int alt_esq = pares(a->esq);
    int alt_dir = pares(a->dir);
    int var = 0;
    if(a->info % 2 == 0)
        var = 1;
    return(alt_esq + alt_dir + var);
}

//segunda questão
int folhas(ArvBin *a){
    if(a == NULL)
        return 0;
    int alt_esq = folhas(a->esq);
    int alt_dir = folhas(a->dir);
    int var = 0;
    if(a->esq == NULL || a->dir == NULL)
        var = 1;
    return(alt_esq + alt_dir + var);
}

//terceira questão
int um_filho(ArvBin *a){
    if(a == NULL)
        return 0;
    int alt_esq = um_filho(a->esq);
    int alt_dir = um_filho(a->dir);
    int var = 0;
    if((a->esq == NULL && a->dir != NULL) || (a->esq != NULL && a->dir == NULL))
        var = 1;
    return(alt_esq + alt_dir + var);
}

//quarta questão
int igual(ArvBin *a, ArvBin *b){
    if(a == NULL && b == NULL)
        return 1;
    if(a == NULL || b == NULL)
        return 0;
    return ((a->info == b->info) && igual(a->esq, b->esq) && igual(a->dir, b->dir));
}

void libera_NO(struct NO* no){
    if(no == NULL)
        return;
    libera_NO(no->esq);
    libera_NO(no->dir);
    free(no);
    no = NULL;
}

void libera_ArvBin(ArvBin* raiz){
    if(raiz == NULL)
        return;
    libera_NO(raiz);
}
