#include <stdlib.h>
#include <stdio.h>

typedef struct no_arvBinB ArvBinB;


ArvBinB *criar();
ArvBinB *busca(ArvBinB *raiz, int v);
ArvBinB *arvbb_busca(ArvBinB *raiz, int v);
void imprime_em_ordem(ArvBinB *r);
void abb_imprime(ArvBinB *raiz);
void desaloca(ArvBinB *r);
void arvbb_desaloca(ArvBinB *raiz);
ArvBinB *insere(ArvBinB *r, int v);
void arvbb_insere(ArvBinB* raiz, int v);
int nfolhas_maiores(ArvBinB *a, int x);
int soma_xy(ArvBinB* a, int x, int y);
int nivel(ArvBinB* a, int x);
void arvbb_retira(ArvBinB *a, int v);
ArvBinB *retira(ArvBinB *r, int v);
