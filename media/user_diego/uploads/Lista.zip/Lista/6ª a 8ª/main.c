#include "questoes.h"

int main()
{
    ArvBinB *raiz = insere(NULL, 4);
    arvbb_insere(raiz, 10);
    arvbb_insere(raiz, 2);
    arvbb_insere(raiz, 7);
    arvbb_insere(raiz, 18);
    arvbb_insere(raiz, 1);
    arvbb_insere(raiz, 3);
    arvbb_insere(raiz, 15);
    arvbb_insere(raiz, 20);

    abb_imprime(raiz);
    int valor = 90;
    printf("\nTemos %d valores maiores que %d", nfolhas_maiores(raiz, valor), valor);
    printf("\nSomatório: %d", soma_xy(raiz, 40, 45));
    printf("\nNível: %d", nivel(raiz, 40));
    arvbb_retira(raiz, 2);
    abb_imprime(raiz);

    return 0;
}
